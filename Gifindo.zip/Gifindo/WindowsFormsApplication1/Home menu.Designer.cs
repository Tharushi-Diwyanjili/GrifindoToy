﻿namespace WindowsFormsApplication1
{
    partial class Home_menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.employeebtn = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.Allsaldetailsbtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Impact", 50F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Navy;
            this.label1.Location = new System.Drawing.Point(157, 125);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(432, 102);
            this.label1.TabIndex = 1;
            this.label1.Text = "HOME MENU";
            // 
            // employeebtn
            // 
            this.employeebtn.BackColor = System.Drawing.Color.Transparent;
            this.employeebtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.employeebtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.employeebtn.FlatAppearance.BorderSize = 0;
            this.employeebtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.employeebtn.Font = new System.Drawing.Font("AnticlaireDisplaySSi", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeebtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.employeebtn.Location = new System.Drawing.Point(219, 254);
            this.employeebtn.Name = "employeebtn";
            this.employeebtn.Size = new System.Drawing.Size(312, 40);
            this.employeebtn.TabIndex = 43;
            this.employeebtn.Text = "Employee Details";
            this.employeebtn.UseVisualStyleBackColor = false;
            this.employeebtn.Click += new System.EventHandler(this.employeebtn_Click_1);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("AnticlaireDisplaySSi", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.button1.Location = new System.Drawing.Point(219, 318);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(312, 44);
            this.button1.TabIndex = 44;
            this.button1.Text = "Setting Details";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Transparent;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button2.Font = new System.Drawing.Font("AnticlaireDisplaySSi", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.button2.Location = new System.Drawing.Point(219, 389);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(312, 44);
            this.button2.TabIndex = 45;
            this.button2.Text = "Salary Details";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // Allsaldetailsbtn
            // 
            this.Allsaldetailsbtn.BackColor = System.Drawing.Color.Transparent;
            this.Allsaldetailsbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Allsaldetailsbtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Allsaldetailsbtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Allsaldetailsbtn.Font = new System.Drawing.Font("AnticlaireDisplaySSi", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Allsaldetailsbtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Allsaldetailsbtn.Location = new System.Drawing.Point(219, 457);
            this.Allsaldetailsbtn.Name = "Allsaldetailsbtn";
            this.Allsaldetailsbtn.Size = new System.Drawing.Size(312, 44);
            this.Allsaldetailsbtn.TabIndex = 46;
            this.Allsaldetailsbtn.Text = "Salary Report";
            this.Allsaldetailsbtn.UseVisualStyleBackColor = false;
            this.Allsaldetailsbtn.Click += new System.EventHandler(this.Allsaldetailsbtn_Click);
            // 
            // Home_menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources._360_F_295671130_iR0BG3MsTDibW9jFhZ0xkRxpKNgLKAvt;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(774, 622);
            this.Controls.Add(this.Allsaldetailsbtn);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.employeebtn);
            this.Controls.Add(this.label1);
            this.Name = "Home_menu";
            this.Text = "Home_menu";
            this.Load += new System.EventHandler(this.Home_menu_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button employeebtn;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button Allsaldetailsbtn;
    }
}